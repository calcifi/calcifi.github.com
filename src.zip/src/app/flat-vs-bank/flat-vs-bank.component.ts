import { Component } from '@angular/core';

@Component({
  selector: 'app-flat-vs-bank',
  templateUrl: './flat-vs-bank.component.html',
  styleUrls: ['./flat-vs-bank.component.scss']
})
export class FlatVsBankComponent {

}
